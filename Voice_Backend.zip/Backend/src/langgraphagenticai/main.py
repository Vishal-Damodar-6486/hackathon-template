# from fastapi import FastAPI, UploadFile, File, HTTPException
# from pydantic import BaseModel
# import os
# import shutil
# from dotenv import load_dotenv

# # Your project's modules
# from .LLMS.openaiLLM import GenAIClient
# from .graph.graph_builder import GraphBuilder
# from .vectorstore.utils import create_vectordb, extract_text

# # Load environment variables
# load_dotenv()

# # Global shared state to hold the LLM and vector database
# # This ensures the vector database persists across API calls
# shared_state = {
#     "llm": None,
#     "vector_db": None,
#     "graph": None
# }

# # Initialize FastAPI app
# app = FastAPI()

# # Pydantic model for the query request body
# class QueryRequest(BaseModel):
#     query: str

# @app.on_event("startup")
# def startup_event():
#     """
#     This function runs once when the application starts up.
#     It initializes the LLM and a placeholder for the graph.
#     """
#     global shared_state
    
#     # Configure and store the LLM
#     try:
#         model = GenAIClient(
#             model=os.getenv("MODEL_PERSONAL"),
#             api_key=os.getenv("OPENAI_API_KEY_PERSONAL"),
#         )
#         shared_state["llm"] = model
#         print("LLM client initialized successfully.")
#     except Exception as e:
#         print(f"Error initializing LLM client: {e}")
#         # Consider a more graceful startup failure in production
#         raise HTTPException(status_code=500, detail="LLM initialization failed.")

# @app.post("/upload-pdf/")
# async def upload_pdf(file: UploadFile = File(...)):
#     """
#     Receives a PDF file, extracts its text, and creates a vector database.
#     """
#     global shared_state
    
#     if not file.filename.endswith(".pdf"):
#         raise HTTPException(status_code=400, detail="Invalid file type. Only PDF files are accepted.")
    
#     # Save the uploaded file temporarily
#     file_location = f"temp_{file.filename}"
#     try:
#         with open(file_location, "wb") as f:
#             shutil.copyfileobj(file.file, f)
        
#         # 1. Load PDF, extract text, and prepare documents
#         print(f"Loading and processing PDF: {file.filename}")
#         extracted_text = extract_text(file_location)
#         if not extracted_text:
#             raise HTTPException(status_code=500, detail="Failed to extract text from the PDF.")
#         document_texts = [extracted_text]
        
#         # 2. Create the vector database
#         print("Creating vector database from document text...")
#         vector_db = create_vectordb(document_texts)
#         shared_state["vector_db"] = vector_db
        
#         # 3. Initialize and store the graph with the new vector DB
#         graph_builder = GraphBuilder(shared_state["llm"], shared_state["vector_db"])
#         shared_state["graph"] = graph_builder.setup_graph("Langgraph Rag")
        
#         return {"message": "PDF processed and vector database created successfully."}

#     except Exception as e:
#         print(f"An error occurred during PDF processing: {e}")
#         raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")
#     finally:
#         # Clean up the temporary file
#         if os.path.exists(file_location):
#             os.remove(file_location)

# @app.post("/query/")
# async def run_query(request: QueryRequest):
#     """
#     Receives a user query and runs the LangGraph RAG workflow.
#     """
#     global shared_state
    
#     if shared_state["vector_db"] is None:
#         raise HTTPException(status_code=400, detail="No vector database found. Please upload a PDF first.")
        
#     if shared_state["graph"] is None:
#         raise HTTPException(status_code=500, detail="LangGraph not initialized. Please upload a PDF to build the graph.")

#     try:
#         query = request.query
#         print(f"Received query: {query}")
        
#         # Run the graph
#         initial_state = {
#             "query": query,
#             "flow_type": "",
#             "document_texts": [],
#             "comparison_results": {},
#             "rag_answer": ""
#         }
#         result = shared_state["graph"].invoke(initial_state)
        
#         # Extract the final answer from the graph state
#         final_answer = result.get("rag_answer")
        
#         if not final_answer:
#             raise HTTPException(status_code=500, detail="LangGraph returned an empty answer.")
            
#         return {"query": query, "answer": final_answer}

#     except Exception as e:
#         print(f"An error occurred during query processing: {e}")
#         raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")
















# # # import streamlit as st
# # import os
# # from .LLMS.openaiLLM import GenAIClient
# # from .graph.graph_builder import GraphBuilder
# # from dotenv import load_dotenv
# # from .vectorstore.utils import create_vectordb, extract_text


# # load_dotenv()

# # BASE_URL = os.getenv("BASE_URL")
# # API_KEY = os.getenv("OPENAI_API_KEY_PERSONAL")
# # MODEL = os.getenv("MODEL_PERSONAL")      
# # PERSONAL_API_KEY = os.getenv("OPENAI_API_KEY_PERSONAL")

# # def run_langgraph_rag():
# #     """
# #     Main function to run the LangGraph RAG application
# #     """

# #     # 1. Load PDF, extract text, and prepare documents
# #     pdf_file_path = r"D:\OneDrive\Documents\PhonePe_Statement_Apr2024_May2025.pdf"  # Replace with your actual PDF path
# #     print(f"Loading and processing PDF: {pdf_file_path}")
# #     try:
# #         extracted_text = extract_text(pdf_file_path)
# #         document_texts = [extracted_text]
# #     except FileNotFoundError:
# #         print(f"Error: PDF file not found at {pdf_file_path}. Exiting.")
# #         return
    
# #     # 2. Create the vector database from the document text
# #     print("Creating vector database from document text...")
# #     vector_db = create_vectordb(document_texts)
# #     print("Vector database created successfully.")


# #     # Configure LLM
# #     # model = GenAIClient(
# #     #         base_url=BASE_URL,
# #     #         model=MODEL,
# #     #         api_key=API_KEY,
# #     #         verify_ssl=False
# #     #     )
    
# #     model = GenAIClient(
# #         model=MODEL,
# #         api_key=PERSONAL_API_KEY, 
# #     )

# #     # Initialize and set up the graph based on use case
# #     usecase = "Langgraph Rag"

# #     query = "What does my spending look like?"

# #     ### Graph Builder
# #     graph_builder = GraphBuilder(model, vector_db)
# #     graph = graph_builder.setup_graph(usecase)
    
# #     # Run the graph
# #     initial_state = {"query": query, "flow_type": "", "document_texts": [], "comparison_results": {}, "rag_answer": ""}
# #     result = graph.invoke(initial_state)
# #     return result

# # if __name__ == "__main__":
# #     run_langgraph_rag()





