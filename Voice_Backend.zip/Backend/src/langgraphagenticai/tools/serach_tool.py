import os
from langchain_community.tools.tavily_search import TavilySearchResults
from langgraph.prebuilt import ToolNode
from dotenv import load_dotenv  

load_dotenv()

TAVILY_API_KEY = os.getenv("TAVILY_API_KEY_PERSONAL")

def get_tools():
    """
    Return the list of tools to be used in the chatbot
    """
    tools=[TavilySearchResults(tavily_api_key=TAVILY_API_KEY, max_results=2)]
    return tools

def create_tool_node(tools):
    """
    creates and returns a tool node for the graph
    """
    return ToolNode(tools=tools)


