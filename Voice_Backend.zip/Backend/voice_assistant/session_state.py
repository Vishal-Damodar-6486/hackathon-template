"""
Session State Management - MINIMAL VERSION
==========================================
Contains ONLY the session state variables actually used in your RFQ Voice Chatbot

USED IN:
- app.py (lines 243-247)
- app_simple.py (lines 208-215)
"""

import streamlit as st


def initialize_voice_session_state():
    """
    Initialize voice-related session state variables
    
    USED IN:
    - app.py lines 243-247: Session state initialization
    - app_simple.py lines 208-215: Session state initialization
    """
    if "chat_history" not in st.session_state:
        st.session_state.chat_history = []

    if "voice_enabled" not in st.session_state:
        st.session_state.voice_enabled = False
