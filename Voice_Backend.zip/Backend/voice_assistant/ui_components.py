"""
Streamlit UI Components - MINIMAL VERSION
=========================================
Contains ONLY the UI components actually used in your RFQ Voice Chatbot

USED IN:
- app.py (lines 310-325, 275-304)
- app_simple.py (lines 272-287, 237-266)
"""

import streamlit as st
from audio_recorder_streamlit import audio_recorder


def create_voice_input_section():
    """
    Create the voice input section with microphone recorder
    
    USED IN:
    - app.py lines 310-325: Voice input section
    - app_simple.py lines 272-287: Voice input section
    """
    st.subheader("🎙️ Voice Input")
    col1, col2 = st.columns([3, 1])
    
    with col1:
        audio_bytes = audio_recorder(
            text="Click to record your question",
            recording_color="#e74c3c",
            neutral_color="#34495e",
            icon_name="microphone",
            icon_size="2x",
        )
    
    with col2:
        if st.button("🎤 Use Voice", help="Click to use voice input"):
            st.info("Click the microphone button to record your question")
    
    return audio_bytes


def create_voice_settings_sidebar():
    """
    Create voice settings in the sidebar
    
    USED IN:
    - app.py lines 298-304: Voice settings in sidebar
    - app_simple.py lines 254-260: Voice settings in sidebar
    """
    st.title("🎤 Voice Settings:")
    
    # Initialize voice_enabled in session state if not exists
    if "voice_enabled" not in st.session_state:
        st.session_state.voice_enabled = False
    
    st.session_state.voice_enabled = st.checkbox(
        "Enable Voice Responses", 
        value=st.session_state.voice_enabled
    )
    
    if st.session_state.voice_enabled:
        st.info("🔊 Voice responses are enabled")
    else:
        st.info("🔇 Voice responses are disabled")


def render_chat_history():
    """
    Render the chat history from session state
    
    USED IN:
    - app.py line 307: render_chat_history()
    - app_simple.py line 269: render_chat_history()
    """
    if "chat_history" not in st.session_state:
        st.session_state.chat_history = []
    
    for role, message in st.session_state.chat_history:
        with st.chat_message(role):
            st.markdown(message)
