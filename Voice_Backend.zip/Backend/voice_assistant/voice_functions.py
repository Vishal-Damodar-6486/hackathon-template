"""
Voice Assistant Core Functions - MINIMAL VERSION
===============================================
Contains ONLY the functions actually used in your RFQ Voice Chatbot

USED IN:
- app.py (lines 49-133)
- app_simple.py (lines 33-115)
"""

import streamlit as st
import io
import requests
import pyttsx3
import threading


def transcribe_audio_with_whisper(audio_bytes):
    """
    Transcribe audio using Azure Whisper model
    
    USED IN: 
    - app.py line 331: transcribed_text = transcribe_audio_with_whisper(audio_bytes)
    - app_simple.py line 293: transcribed_text = transcribe_audio_with_whisper(audio_bytes)
    """
    try:
        headers = {
            "Authorization": "Bearer sk-g0RigALF05KUmlonLK3JHg"
        }
        
        files = {
            "file": ("audio.wav", io.BytesIO(audio_bytes), "audio/wav")
        }
        
        data = {
            "model": "azure/genailab-maas-whisper",
            "language": "en",
            "response_format": "text"
        }
        
        response = requests.post(
            "https://genailab.tcs.in/v1/audio/transcriptions",
            headers=headers,
            files=files,
            data=data,
            verify=False
        )
        
        if response.status_code == 200:
            try:
                result = response.json()
                return result.get("text", "").strip()
            except:
                return response.text.strip()
        else:
            st.error(f"Transcription failed: {response.status_code} - {response.text}")
            return None
            
    except Exception as e:
        st.error(f"Error in transcription: {str(e)}")
        return None


def text_to_speech(text):
    """
    Convert text to speech using pyttsx3
    
    USED IN:
    - app.py line 125: text_to_speech(text_to_speak)
    - app_simple.py line 109: text_to_speech(text_to_speak)
    """
    try:
        engine = pyttsx3.init()
        
        voices = engine.getProperty('voices')
        if voices:
            engine.setProperty('voice', voices[0].id)
        
        engine.setProperty('rate', 150)
        engine.setProperty('volume', 0.8)
        
        engine.say(text)
        engine.runAndWait()
        
        return True
        
    except Exception as e:
        st.error(f"Error in text-to-speech: {str(e)}")
        return False


def play_audio_response(text):
    """
    Play audio response in a separate thread
    
    USED IN:
    - app.py line 355: play_audio_response(final_response)
    - app.py line 383: play_audio_response(final_response)
    - app_simple.py line 316: play_audio_response(final_response)
    - app_simple.py line 343: play_audio_response(final_response)
    """
    def play_tts():
        try:
            if len(text) > 500:
                text_to_speak = text[:500] + "... Response continues in text."
            else:
                text_to_speak = text
            
            text_to_speech(text_to_speak)
        except Exception as e:
            st.error(f"Error in audio playback: {str(e)}")
    
    tts_thread = threading.Thread(target=play_tts)
    tts_thread.daemon = True
    tts_thread.start()
