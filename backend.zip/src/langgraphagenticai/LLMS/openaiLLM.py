import httpx
from langchain_openai import ChatOpenAI

class GenAIClient:
    def __init__(self, base_url: str, model: str, api_key: str, verify_ssl: bool = False):
        self.base_url = base_url
        self.model = model
        self.api_key = api_key
        self.http_client = httpx.Client(verify=verify_ssl)
        self.llm = self._create_llm_client()
    
    def get_llm(self):
        """Return the LLM instance for compatibility"""
        return self.llm

    def _create_llm_client(self) -> ChatOpenAI:
        """
        Initialize the ChatOpenAI client with the provided config.
        """
        return ChatOpenAI(
            base_url=self.base_url,
            model=self.model,
            api_key=self.api_key,
            http_client=self.http_client
        )

    def get_response(self, prompt: str) -> str:
        """
        Invoke the language model with the given prompt and return the response.
        """
        return self.llm.invoke(prompt)

    def close(self):
        """
        Close the HTTP client when done to free resources.
        """
        self.http_client.close()