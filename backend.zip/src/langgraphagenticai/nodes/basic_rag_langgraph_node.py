from ..state.state import State, GraphState
from langchain_openai import OpenAIEmbeddings
from langchain_core.prompts import ChatPromptTemplate
from langchain_community.vectorstores import Chroma
from langchain_core.output_parsers import JsonOutputParser, StrOutputParser

import httpx

# Create HTTP client with verify=False for LangChain
client = httpx.Client(verify=False)

class BasicRagLanggraph:
    """
    Chatbot logic enhanced with tool integration.
    """
    def __init__(self,model):
        self.llm = model.llm if hasattr(model, 'llm') else model

    def router(self, query : str):

        system_prompt = """
                You are an AI assistant that classifies user queries into three categories:
                - "compare" if the query involves comparing two documents.
                - "rag" if the query requires question-answering with a retrieval-based solution.
                - "end" if the user wants to quit/exit.

                Return the response in **strict JSON format**, with **only one key**: classifier.
                Do not include any explanations or extra text.
                """
        router_prompt = ChatPromptTemplate([
        ("system",system_prompt),
        ("user", "{query}")
        ])

        # structured_llm= llm.with_structured_output(router_class)
        parser = JsonOutputParser()
        chain=router_prompt | self.llm |parser
        response=chain.invoke({"query":query})
        return response


    def decision_node(self, state: GraphState) -> GraphState: 
        print("Decision node started")
        
        # Use existing query from state or set a default test query
        if not state.query:
            query = "What is artificial intelligence?"  # Default test query
            state = state.copy(update={"query": query})
            print(f"Using default query: {query}")
        else:
            print(f"Using provided query: {state.query}")
        
        res = self.router(state.query)
        flow_type = ""
        print(f"Router response: {res}")
        
        if "end" in res['classifier']:
            flow_type = "end"
        else:
            flow_type = "rag"
            
        state = state.copy(update={"flow_type": flow_type})
        print(f"Flow type determined: {flow_type}")
        return state
    
    def qa_node(self, state: GraphState) -> GraphState: 
        print(f"QA node processing query: {state.query}")
        
        # For now, let's create a simple response without vector store to test the flow
        try:
            prompt = ChatPromptTemplate.from_template(
                """
                You are an AI assistant. Answer the following question to the best of your ability.
                
                Question: {question}
                
                Answer:
                """
            )
            
            chain = prompt | self.llm | StrOutputParser()
            response = chain.invoke({"question": state.query})
            
            print(f"Generated response: {response}")
            state = state.copy(update={"rag_answer": response})
            
        except Exception as e:
            print(f"Error in QA node: {e}")
            state = state.copy(update={"rag_answer": f"Error processing query: {str(e)}"})
        
        return state

    
    def end_node(self, state: GraphState) -> GraphState:
        print("workflow has ended")
        return state

