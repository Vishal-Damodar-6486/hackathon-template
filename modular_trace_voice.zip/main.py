from fastapi import FastAPI, UploadFile, File, HTTPException
from pydantic import BaseModel
import os
import shutil
from dotenv import load_dotenv
import traceback
import io
import requests

# Your project's modules
from src.langgraphagenticai.LLMS.openaiLLM import GenAIClient
from src.langgraphagenticai.graph.graph_builder import GraphBuilder
from src.langgraphagenticai.vectorstore.utils import create_vectordb, extract_text

# Load environment variables
load_dotenv()

# Global shared state to hold the LLM and vector database
# This ensures the vector database persists across API calls
shared_state = {
    "llm": None,
    "vector_db": None,
    "graph": None
}

# Initialize FastAPI app
app = FastAPI()

# Pydantic model for the query request body
class QueryRequest(BaseModel):
    query: str

@app.on_event("startup")
def startup_event():
    """
    This function runs once when the application starts up.
    It initializes the LLM and a placeholder for the graph.
    """
    global shared_state
    
    # Configure and store the LLM
    try:
        model = GenAIClient(
            model=os.getenv("MODEL"),
            api_key=os.getenv("OPENAI_API_KEY"),
            base_url=os.getenv("BASE_URL"),
            verify_ssl=False
        )
        shared_state["llm"] = model
        print("LLM client initialized successfully.")
    except Exception as e:
        print(f"Error initializing LLM client: {e}")
        # Consider a more graceful startup failure in production
        raise HTTPException(status_code=500, detail="LLM initialization failed.")

@app.post("/upload-pdf/")
async def upload_pdf(file: UploadFile = File(...)):
    """
    Receives a PDF file, extracts its text, and creates a vector database.
    """
    global shared_state
    
    if not file.filename.endswith(".pdf"):
        raise HTTPException(status_code=400, detail="Invalid file type. Only PDF files are accepted.")
    
    # Save the uploaded file temporarily
    file_location = f"temp_{file.filename}"
    try:
        with open(file_location, "wb") as f:
            shutil.copyfileobj(file.file, f)
        
        # 1. Load PDF, extract text, and prepare documents
        print(f"Loading and processing PDF: {file.filename}")
        extracted_text = extract_text(file_location)
        if not extracted_text:
            raise HTTPException(status_code=500, detail="Failed to extract text from the PDF.")
        document_texts = [extracted_text]
        
        # 2. Create the vector database
        print("Creating vector database from document text...")
        vector_db = create_vectordb(document_texts)
        shared_state["vector_db"] = vector_db
        
        # 3. Initialize and store the graph with the new vector DB
        graph_builder = GraphBuilder(shared_state["llm"], shared_state["vector_db"])
        shared_state["graph"] = graph_builder.setup_graph("Langgraph Rag")                                         # Changable to "Langgraph Rag"
        
        return {"message": "PDF processed and vector database created successfully."}

    except Exception as e:
        print(f"An error occurred during PDF processing: {e}")
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")
    finally:
        # Clean up the temporary file
        if os.path.exists(file_location):
            os.remove(file_location)

@app.post("/query/")
async def run_query(request: QueryRequest):
    """
    Receives a user query and runs the LangGraph RAG workflow.
    """
    global shared_state
    
    if shared_state["vector_db"] is None:
        raise HTTPException(status_code=400, detail="No vector database found. Please upload a PDF first.")
        
    if shared_state["graph"] is None:
        raise HTTPException(status_code=500, detail="LangGraph not initialized. Please upload a PDF to build the graph.")

    try:
        query = request.query
        print(f"Received query: {query}")
        
        # Run the graph
        initial_state = {
            "query": query,
            "flow_type": "",
            "document_texts": [],
            "comparison_results": {},
            "rag_answer": ""
        }
        print("Invoking LangGraph with initial state:", initial_state)
        graph_builder = GraphBuilder(shared_state["llm"], shared_state["vector_db"])
        result = graph_builder.graph_invoke(initial_state, shared_state)
        
        # Extract the final answer from the graph state
        final_answer = result.get("rag_answer")
        
        if not final_answer:
            raise HTTPException(status_code=500, detail="LangGraph returned an empty answer.")
            
        return {"query": query, "answer": final_answer}

    except Exception as e:
        print(f"An error occurred during query processing: {e}")
        traceback.print_exc() 

        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

@app.post("/transcribe-audio/")
async def transcribe_audio(file: UploadFile = File(...)):
    """
    Transcribe audio file using Azure Whisper model
    """
    try:
        # Read audio file content
        audio_bytes = await file.read()
        
        headers = {
            "Authorization": "Bearer sk-g0RigALF05KUmlonLK3JHg"
        }
        
        files = {
            "file": (file.filename, io.BytesIO(audio_bytes), "audio/wav")
        }
        
        data = {
            "model": "azure/genailab-maas-whisper",
            "language": "en",
            "response_format": "text"
        }
        
        response = requests.post(
            "https://genailab.tcs.in/v1/audio/transcriptions",
            headers=headers,
            files=files,
            data=data,
            verify=False
        )
        
        if response.status_code == 200:
            try:
                result = response.json()
                transcribed_text = result.get("text", "").strip()
            except:
                transcribed_text = response.text.strip()
            
            return {"transcribed_text": transcribed_text}
        else:
            raise HTTPException(status_code=response.status_code, detail=f"Transcription failed: {response.text}")
            
    except Exception as e:
        print(f"Error in transcription: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Transcription error: {str(e)}")