from ..state.state import GraphState

class ChatbotWithToolNode:
    """
    Chatbot logic enhanced with tool integration.
    """
    def __init__(self,model):
        self.llm = model

    def process(self, state: GraphState) -> dict:
        """
        Processes the input state and generates a response with tool integration.
        """
        user_input = state["query"]
        llm_response = self.llm.invoke([{"role": "user", "content": user_input}])

        # Simulate tool-specific logic
        tools_response = f"Tool integration for: '{user_input}'"

        return {"messages": [llm_response, tools_response]}
    
    # In ChatbotWithToolNode class
    def create_chatbot(self, tools):
        llm_with_tools = self.llm.bind_tools(tools)
        print("LLM with tools bound:", llm_with_tools)
        
        def chatbot_node(state: GraphState):
            print(f"Chatbot node received state: {state}")
            messages = []
            # Append the new user query to the messages
            messages.append({"role": "user", "content": state.query})

            # Invoke the LLM with the full message history
            response = self.llm.invoke(messages)

            # Append the LLM's response to the message history
            messages.append(response)

            # Return the updated messages list and the rag_answer
            return {"messages": messages, "rag_answer": response.content}


        print("Chatbot node created with tools.")
        return chatbot_node