from typing import Annotated, Literal, Optional
from typing_extensions import TypedDict
from langgraph.graph.message import add_messages
from typing import TypedDict, Annotated, List, Dict
from pydantic import BaseModel, Field

class State(TypedDict):
    """
    Represents the structure of the state used in the graph.
    """
    messages: Annotated[list, add_messages]

class GraphState(BaseModel): 
    query: str = Field(default="", description="User query input") 
    flow_type: str = Field(default="", description="Determines whether to perform comparison or Q&A") 
    document_texts: List[str] = Field(default_factory=list, description="List of document texts to process") 
    comparison_results: Dict[str, List[str]] = Field(default_factory=dict, description="Stores commonalities and differences between documents") 
    rag_answer: str = Field(default="", description="Stores the RAG-based answer for Q&A flow")