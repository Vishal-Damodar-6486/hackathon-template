import requests
import os 
from langsmith import Client
from dotenv import load_dotenv

load_dotenv()

def Client_without_Session():
    Session=requests.Session()
    Session.verify=False
    langSmith_client=Client(session=Session)
    return langSmith_client