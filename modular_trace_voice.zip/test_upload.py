import requests
import os

# Test the upload endpoint with a simple PDF
def test_upload():
    url = "http://127.0.0.1:8000/upload-pdf/"
    
    # Create a simple test PDF file (or use an existing one)
    # For now, let's just test with any PDF file in the directory
    pdf_files = [f for f in os.listdir('.') if f.endswith('.pdf')]
    
    if not pdf_files:
        print("No PDF files found in current directory. Please add a test PDF file.")
        return
    
    test_file = pdf_files[0]
    print(f"Testing upload with file: {test_file}")
    
    try:
        with open(test_file, 'rb') as f:
            files = {'file': (test_file, f, 'application/pdf')}
            response = requests.post(url, files=files)
            
        print(f"Status Code: {response.status_code}")
        print(f"Response: {response.text}")
        
    except Exception as e:
        print(f"Error during upload test: {e}")

if __name__ == "__main__":
    test_upload()
