import streamlit as st
import requests
import json
import time

# Import voice assistant components
from voice_assistant.voice_functions import (
    transcribe_audio_with_whisper,
    text_to_speech, 
    play_audio_response
)
from voice_assistant.ui_components import (
    create_voice_input_section,
    create_voice_settings_sidebar,
    render_chat_history
)
from voice_assistant.session_state import initialize_voice_session_state

# FastAPI server URL
FASTAPI_URL = "http://127.0.0.1:8000"

st.set_page_config(page_title="LangGraph RAG Demo", layout="wide")

# Initialize voice session state
initialize_voice_session_state()

st.title("LangGraph RAG with FastAPI 🤖")
st.markdown("Upload a PDF to create a knowledge base, then ask questions about its content.")

st.sidebar.header("Upload Document")
uploaded_file = st.sidebar.file_uploader("Choose a PDF file", type="pdf")
upload_button = st.sidebar.button("Upload PDF")

if upload_button and uploaded_file is not None:
    st.sidebar.info("Uploading file...")
    files = {
        'file': (uploaded_file.name, uploaded_file.getvalue(), 'application/pdf')
    }

    with st.spinner("Processing PDF... This may take a moment."):
        try:
            response = requests.post(f"{FASTAPI_URL}/upload-pdf/", files=files)
            if response.status_code == 200:
                st.sidebar.success("PDF processed successfully! You can now ask questions.")
            else:
                st.sidebar.error(f"Error processing PDF: {response.json().get('detail', 'Unknown error')}")
        except requests.exceptions.ConnectionError:
            st.sidebar.error("Could not connect to the FastAPI server. Please ensure it is running.")
        except Exception as e:
            st.sidebar.error(f"An unexpected error occurred: {e}")
elif upload_button and uploaded_file is None:
    st.sidebar.warning("Please select a PDF file before clicking 'Upload PDF'.")

# Add voice settings to sidebar
st.sidebar.markdown("---")
create_voice_settings_sidebar()


st.header("Ask a Question")

# Input for the user query
query = st.text_input("Enter your query:", placeholder="e.g., What does my spending look like?")

# Add voice input section
audio_bytes = create_voice_input_section()

# Handle voice input
if audio_bytes is not None:
    with st.spinner("Transcribing audio..."):
        transcribed_text = transcribe_audio_with_whisper(audio_bytes)
        if transcribed_text:
            query = transcribed_text
            st.success(f"Voice input transcribed: {transcribed_text}")
        else:
            st.error("Failed to transcribe audio. Please try again.")

# Display chat history
st.subheader("💬 Chat History")
render_chat_history()

# Add clear chat history button
if st.button("🗑️ Clear Chat History"):
    st.session_state.chat_history = []
    st.success("Chat history cleared!")
    st.experimental_rerun()

if st.button("Get Answer"):
    if not query:
        st.warning("Please enter a query.")
    else:
        with st.spinner("Generating response..."):
            try:
                # Prepare the JSON payload
                payload = {"query": query}
                headers = {"Content-Type": "application/json"}
                
                # Send the query to the FastAPI endpoint
                response = requests.post(f"{FASTAPI_URL}/query/", data=json.dumps(payload), headers=headers)
                
                if response.status_code == 200:
                    answer = response.json().get("answer")
                    
                    # Add to chat history
                    st.session_state.chat_history.append(("user", query))
                    st.session_state.chat_history.append(("assistant", answer))
                    
                    # Display answer
                    st.success("Answer:")
                    st.write(answer)
                    
                    # Play voice response if enabled
                    if st.session_state.voice_enabled:
                        with st.spinner("Playing voice response..."):
                            play_audio_response(answer)
                    
                elif response.status_code == 400:
                    error_msg = f"Error: {response.json().get('detail', 'Bad Request')}"
                    st.error(error_msg)
                    st.session_state.chat_history.append(("user", query))
                    st.session_state.chat_history.append(("assistant", error_msg))
                else:
                    error_msg = f"Error: {response.json().get('detail', 'Unknown error')}"
                    st.error(error_msg)
                    st.session_state.chat_history.append(("user", query))
                    st.session_state.chat_history.append(("assistant", error_msg))
            except requests.exceptions.ConnectionError:
                error_msg = "Could not connect to the FastAPI server. Is it running?"
                st.error(error_msg)
                st.session_state.chat_history.append(("user", query))
                st.session_state.chat_history.append(("assistant", error_msg))
            except Exception as e:
                error_msg = f"An unexpected error occurred: {e}"
                st.error(error_msg)
                st.session_state.chat_history.append(("user", query))
                st.session_state.chat_history.append(("assistant", error_msg))