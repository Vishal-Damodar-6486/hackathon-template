# Voice Assistant Components - MINIMAL VERSION

This folder contains ONLY the voice assistant functionality that's actually used in your RFQ Voice Chatbot.

## 📁 Files (Minimal)

```
voice_assistant/
├── voice_functions.py    # 3 core voice functions
├── ui_components.py      # 3 UI components  
├── session_state.py     # 2 session state variables
├── requirements.txt     # 4 essential dependencies
└── README.md           # This file
```

## 🎯 What's Included (Actually Used)

### `voice_functions.py` - 3 Functions
1. `transcribe_audio_with_whisper()` - Used in app.py line 331, app_simple.py line 293
2. `text_to_speech()` - Used in app.py line 125, app_simple.py line 109  
3. `play_audio_response()` - Used in app.py lines 355,383, app_simple.py lines 316,343

### `ui_components.py` - 3 Components
1. `create_voice_input_section()` - Used in app.py lines 310-325, app_simple.py lines 272-287
2. `create_voice_settings_sidebar()` - Used in app.py lines 298-304, app_simple.py lines 254-260
3. `render_chat_history()` - Used in app.py line 307, app_simple.py line 269

### `session_state.py` - 2 Variables
1. `chat_history` - Used in app.py line 244, app_simple.py line 209
2. `voice_enabled` - Used in app.py line 247, app_simple.py line 212

### `requirements.txt` - 4 Dependencies
1. `streamlit>=1.28.0`
2. `audio-recorder-streamlit>=0.0.8` 
3. `pyttsx3>=2.90`
4. `requests>=2.31.0`

## 🚀 How to Use

### Copy to Your Project
```python
from voice_assistant.voice_functions import (
    transcribe_audio_with_whisper,
    text_to_speech, 
    play_audio_response
)
from voice_assistant.ui_components import (
    create_voice_input_section,
    create_voice_settings_sidebar,
    render_chat_history
)
from voice_assistant.session_state import initialize_voice_session_state
```

### Replace in Your Main App
Instead of having the functions directly in your main file, import them:

```python
# Replace the embedded functions in app.py/app_simple.py with imports
# Then use exactly as before - no other changes needed!
```

## ✅ Perfect Match
This minimal version contains exactly what you're using - nothing more, nothing less!
