import httpx
from langchain_openai import ChatOpenAI

class GenAIClient:
    def __init__(
        self,
        model: str,
        api_key: str,
        base_url: str | None = None,
        verify_ssl: bool = False,
        **kwargs  # allow extra params like 'organization'
    ):
        self.model = model
        self.api_key = api_key
        self.base_url = base_url
        self.http_client = httpx.Client(verify=verify_ssl)
        self.llm = self._create_llm_client(**kwargs)
    
    def get_llm(self):
        """Return the LLM instance for compatibility"""
        return self.llm

    def _create_llm_client(self, **kwargs) -> ChatOpenAI:
        """
        Initialize the ChatOpenAI client with the provided config.
        """
        return ChatOpenAI(
            model=self.model,
            api_key=self.api_key,
            base_url=self.base_url,
            http_client=self.http_client,
            **kwargs  # pass through extras
        )

    def get_response(self, prompt: str) -> str:
        """
        Invoke the language model with the given prompt and return the response.
        """
        return self.llm.invoke(prompt)

    def close(self):
        """
        Close the HTTP client when done to free resources.
        """
        self.http_client.close()