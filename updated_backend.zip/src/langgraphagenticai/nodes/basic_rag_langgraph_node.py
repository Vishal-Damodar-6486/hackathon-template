import os
from ..state.state import GraphState
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import JsonOutputParser, StrOutputParser
from langchain_core.runnables import RunnablePassthrough
from langchain_core.prompts import PromptTemplate
from langchain_community.vectorstores import Chroma
from langchain_openai import OpenAIEmbeddings
import httpx
from dotenv import load_dotenv

load_dotenv()

# Create HTTP client with verify=False for LangChain
client = httpx.Client(verify=False)

API_KEY=os.getenv("OPENAI_API_KEY_PERSONAL")
BASE_URL=os.getenv("BASE_URL")
MODEL=os.getenv("MODEL_PERSONAL")

class BasicRagLanggraph:
    """
    Chatbot logic enhanced with tool integration.
    """
    def __init__(self, model, vector_db):
        self.llm = model.llm if hasattr(model, 'llm') else model
        self.vector_db = vector_db
        self.retriever = self.vector_db.as_retriever()

    def router(self, query : str):

        system_prompt = """
                You are an AI assistant that classifies user queries into three categories:
                - "compare" if the query involves comparing two documents.
                - "rag" if the query requires question-answering with a retrieval-based solution.
                - "end" if the user wants to quit/exit.

                Return the response in **strict JSON format**, with **only one key**: classifier.
                Do not include any explanations or extra text.
                """
        router_prompt = ChatPromptTemplate([
        ("system",system_prompt),
        ("user", "{query}")
        ])

        # structured_llm= llm.with_structured_output(router_class)
        parser = JsonOutputParser()
        chain=router_prompt | self.llm |parser
        response=chain.invoke({"query":query})
        return response


    def decision_node(self, state: GraphState) -> GraphState: 
        print("Decision node started")
        
        # Use existing query from state or set a default test query
        if not state.query:
            query = "What is artificial intelligence?"  # Default test query
            state = state.copy(update={"query": query})
            print(f"Using default query: {query}")
        else:
            print(f"Using provided query: {state.query}")
        
        res = self.router(state.query)
        flow_type = ""
        print(f"Router response: {res}")
        
        if "end" in res['classifier']:
            flow_type = "end"
        else:
            flow_type = "rag"
            
        state = state.copy(update={"flow_type": flow_type})
        print(f"Flow type determined: {flow_type}")
        return state
    
    def qa_node(self, state: GraphState) -> GraphState:
        print(f"QA node processing query with RAG: {state.query}")
        
        # Define a prompt template that includes context and question placeholders
        prompt_template = PromptTemplate(
            template="""
            Use the following context to answer the question. If you don't know the answer, just say that you don't know.
            
            Context:
            {context}
            
            Question: {question}
            
            Answer:
            """,
            input_variables=["context", "question"]
        )

        rag_chain = (
            {"context": self.retriever, "question": RunnablePassthrough()}
            | prompt_template
            | self.llm
            | StrOutputParser()
        )
        
        try:
            # Invoke the RAG chain with the user's query
            response = rag_chain.invoke(state.query)
            
            print(f"Generated RAG response: {response}")
            state = state.copy(update={"rag_answer": response})
            
        except Exception as e:
            print(f"Error in QA node: {e}")
            state = state.copy(update={"rag_answer": f"Error processing query: {str(e)}"})
        
        return state


    
    def end_node(self, state: GraphState) -> GraphState:
        print("workflow has ended")
        return state

