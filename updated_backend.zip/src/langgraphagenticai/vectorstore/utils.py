from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import Chroma, FAISS
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_core.documents import Document
from pypdf import PdfReader
from dotenv import load_dotenv
import os
load_dotenv()

API_KEY = os.getenv("OPENAI_API_KEY_PERSONAL")

def extract_text(file_path: str) -> str:
    """
    Extracts all text from a PDF file.

    Args:
        file_path (str): The path to the PDF file.

    Returns:
        str: A single string containing all the text from the document.
    """
    try:
        reader = PdfReader(file_path)
        text = ""
        for page in reader.pages:
            text += page.extract_text()
        return text
    except Exception as e:
        print(f"Error extracting text from PDF: {e}")
        return ""


def create_vectordb(documents: list[str], db_type: str = "chroma"):
    """
    Creates and populates a vector database from a list of documents.

    Args:
        documents (list[str]): A list of strings, where each string is a document.
        db_type (str): The type of vector database to create ("chroma" or "faiss").
                       Defaults to "faiss".

    Returns:
        VectorStore: An instance of the populated vector store (Chroma or FAISS).
    """
    # Initialize the text splitter
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)

    # Convert the list of strings into a list of LangChain Document objects
    # This is a good practice as many methods expect this format
    docs = [Document(page_content=d) for d in documents]
    
    # Split the documents into chunks
    split_docs = text_splitter.split_documents(docs)

    # Initialize the embeddings model
    # Ensure you have your API key set up in the environment variables
    # embeddings = OpenAIEmbeddings(
            #     base_url=BASE_URL,
            #     model=MODEL,
            #     api_key=API_KEY,
            #     verify_ssl=False
            #     )
    embeddings = OpenAIEmbeddings(
                api_key=API_KEY,
                )

    # Create the vector store based on the specified type
    if db_type.lower() == "chroma":
        vectordb = Chroma.from_documents(documents=split_docs, embedding=embeddings)
    elif db_type.lower() == "faiss":
        vectordb = FAISS.from_documents(documents=split_docs, embedding=embeddings)
    else:
        raise ValueError("Unsupported database type. Please choose 'chroma' or 'faiss'.")
    
    return vectordb