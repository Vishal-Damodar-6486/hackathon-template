import streamlit as st
import requests
import json
import time

# FastAPI server URL
FASTAPI_URL = "http://127.0.0.1:8000"

st.set_page_config(page_title="LangGraph RAG Demo", layout="wide")

st.title("LangGraph RAG with FastAPI 🤖")
st.markdown("Upload a PDF to create a knowledge base, then ask questions about its content.")

st.sidebar.header("Upload Document")
uploaded_file = st.sidebar.file_uploader("Choose a PDF file", type="pdf")
upload_button = st.sidebar.button("Upload PDF")

if upload_button and uploaded_file is not None:
    st.sidebar.info("Uploading file...")
    files = {
        'file': (uploaded_file.name, uploaded_file.getvalue(), 'application/pdf')
    }

    with st.spinner("Processing PDF... This may take a moment."):
        try:
            response = requests.post(f"{FASTAPI_URL}/upload-pdf/", files=files)
            if response.status_code == 200:
                st.sidebar.success("PDF processed successfully! You can now ask questions.")
            else:
                st.sidebar.error(f"Error processing PDF: {response.json().get('detail', 'Unknown error')}")
        except requests.exceptions.ConnectionError:
            st.sidebar.error("Could not connect to the FastAPI server. Please ensure it is running.")
        except Exception as e:
            st.sidebar.error(f"An unexpected error occurred: {e}")
elif upload_button and uploaded_file is None:
    st.sidebar.warning("Please select a PDF file before clicking 'Upload PDF'.")


st.header("Ask a Question")

# Input for the user query
query = st.text_input("Enter your query:", placeholder="e.g., What does my spending look like?")

if st.button("Get Answer"):
    if not query:
        st.warning("Please enter a query.")
    else:
        with st.spinner("Generating response..."):
            try:
                # Prepare the JSON payload
                payload = {"query": query}
                headers = {"Content-Type": "application/json"}
                
                # Send the query to the FastAPI endpoint
                response = requests.post(f"{FASTAPI_URL}/query/", data=json.dumps(payload), headers=headers)
                
                if response.status_code == 200:
                    answer = response.json().get("answer")
                    st.success("Answer:")
                    st.write(answer)
                elif response.status_code == 400:
                    st.error(f"Error: {response.json().get('detail', 'Bad Request')}")
                else:
                    st.error(f"Error: {response.json().get('detail', 'Unknown error')}")
            except requests.exceptions.ConnectionError:
                st.error("Could not connect to the FastAPI server. Is it running?")
            except Exception as e:
                st.error(f"An unexpected error occurred: {e}")